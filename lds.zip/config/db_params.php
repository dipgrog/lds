<?php
return array(
    'host' => 'localhost',
    'dbname' => 'ldstest',
    'user' => 'root',
    'password' => '',            
);