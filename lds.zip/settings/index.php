<?php 
include('../layout/header.php');
include('../components/db_connection.php');
include('settings.php');
include('../layout/footer.php');
?>