<div id="sidebar">
        <ul class="sideul">
            <li>
                <span class="ion-ios-home-outline sbf"></span>
                <br>
                <span id="default">Главная</span>
            </li>
            <li>
                <span class="ion-ios-list-outline sbf"></span>
                <br>
                <span id="default">Заявки</span>
            </li>
            <li>
                <i class="ion-ios-people-outline sbf"></i>
                <br>
                <span id="default">Клиенты</span>
            </li>
            <li>
                <i class="ion-ios-filing-outline sbf"></i>
                <br>
                <span id="default">Склад</span>
            </li>
            <a href="?target=status">
            <li class="active">
                <i class="ion-ios-gear-outline sbf"></i>
                <br>
                <span id="default">Настройки</span>
            </li>
            </a>
        </ul>
</div>