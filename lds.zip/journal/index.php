<?php 
include('../layout/header.php');
include('../components/db_connection.php');
include('journal.php');
include('../layout/footer.php');
?>