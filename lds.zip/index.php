<?php 
include('header.php');
include('components/db_connection.php');
include('settings.php');
include('footer.php');
?>