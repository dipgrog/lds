<?php 
ini_set('display_errors',1);
error_reporting(E_ALL); 
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Учет ремонта оборудования</title>
	<link rel="stylesheet" type="text/css" href="../css/form.css">
	<link rel="stylesheet" type="text/css" href="../css/ionicons.min.css">
</head>
<body>