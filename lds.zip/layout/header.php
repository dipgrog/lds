<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Форма статусов</title>
	<link rel="stylesheet" type="text/css" href="../css/form.css">
	<link rel="stylesheet" type="text/css" href="../css/ionicons.min.css">
</head>
<body>