

    <div class="container">
         <?php include ('sidebar.php') ?>
        <div class="lside">&nbsp</div>
        <div id="content">
            <div id="title">
                <h1>Контрагенты</h1>
                <!-- <h3>Учет по клиентам (в основном по кассам)</h3> -->
            </div>
            <div class="navbar">
                <div class="navblock">
                <!-- <ul class="navul"> -->

                    <a href="?page=clientedit"><dip class="btn pos">Добавить</dip></a>
                    <!-- <a href="?target=type"><li class="btn">Юр. лица</li></a> -->
                    <!-- <a href="?target=opf"><li class="btn">Физ. лица</li></a>   -->
                <!-- </ul> -->
                </div>
                <div class="navblock">
                <form class="formright" action="" method="POST" >
                    <input class="btn pos" type="submit" name="submit" value="Поиск">
                    <input class="inputfield" type="text" name="name" placeholder="Введите строку поиска">
       
                </form>
                </div>
            </div>
            <!-- <div class="pad"></div> -->
            
            <div class="pad"></div>

            <div class="tabl">

                <table>
                    <tr>
                        <th id="fst">№</th>
                        <th>Контрагент</th>
                        <th>Телефон</th>
                        <th>Договор</th>
                        <th>Сумма</th>
                        <th>Мастер</th>


                    </tr>
                    <tr>
                        <td>&nbsp</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    


                </table>
            </div>
        </div>
    </div>