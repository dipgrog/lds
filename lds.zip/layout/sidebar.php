        <div id="sidebar">
            <ul class="sideul">
                <a href="../">
                    <li>
                        <span class="ion-ios-home-outline sbf"></span>
                        <br>
                        <span id="default">Главная</span>
                    </li>
                </a>
                <a href="../journal">
                    <li  >
                        <span class="ion-ios-list-outline sbf"></span>
                        <br>
                        <span id="default">Журнал</span>
                    </li>
                </a>
                <a href="../client">
                    <li class="active">
                        <i class="ion-ios-people-outline sbf"></i>
                        <br>
                        <span id="default">Клиенты</span>
                    </li>
                </a>
                <a href="../store">
                    <li>
                        <i class="ion-ios-calculator-outline sbf"></i>
                        <br>
                        <span id="default">ККТ</span>
                    </li>
                </a>
               <a href="../store">
                    <li>
                        <i class="ion-ios-filing-outline sbf"></i>
                        <br>
                        <span id="default">Склад</span>
                    </li>
                </a>
                <a href="../settings">
                    <li>
                        <i class="ion-ios-gear-outline sbf"></i>
                        <br>
                        <span id="default">Настройки</span>
                    </li>
                </a>
            </ul>
        </div>