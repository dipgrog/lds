 <div class="container">
        <?php include ('sidebar.php') ?>
         <div class="lside">&nbsp</div>
         <div id="content">
            <div id="title">
                <h1>Добавление контрагента</h1>
                <!-- <h3>Учет по клиентам (в основном по кассам)</h3> -->
            </div>
<div class="addclient">

	<form action="" method="POST" class="client-form">

		<label for="opf">Организационно правовая форма</label><br>
		<select id="opf">
			<option></option>
			<option>ООО - Общество с ограниченной ответственностью</option>
			<option>ИП - Индивидуальный предприниматель</option>
			<option>ФЛ - Физическое лицо</option>
		</select><br>
		<label for="name">Наименование организации или Ф.И.О. физ. лица</label><br>
		<input id="name" type="text" name="name" placeholder="Наименование"><br>
		<label for="inn">ИНН</label><br>
		<input id="inn" type="text" name="name" placeholder="ИНН"><br>
		<label for="adress">Адрес</label><br>
		<input id="adress" type="text" name="adress" placeholder="Адрес"><br>
		<label for="tel">Телефон</label><br>
		<input id="tel" type="text" name="tel" placeholder="Телефон"><br>
		<input class="btn pos" type="submit" name="submit" value="Записать"><br>
	</form>
</div>
</div>
</div>
