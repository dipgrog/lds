<div id="wrapper">
    <div id="sidebar">
        <ul class="sideul">
            <li>
                <span class="ion-ios-home-outline sbf"></span>
                <br>
                <span id="default">Главная</span>
            </li>
            <li>
                <span class="ion-ios-list-outline sbf"></span>
                <br>
                <span id="default">Заявки</span>
            </li>
            <li>
                <i class="ion-ios-people-outline sbf"></i>
                <br>
                <span id="default">Клиенты</span>
            </li>
            <li>
                <i class="ion-ios-filing-outline sbf"></i>
                <br>
                <span id="default">Склад</span>
            </li>
            <li class="active">
                <i class="ion-ios-gear-outline sbf"></i>
                <br>
                <span id="default">Настройки</span>
            </li>
        </ul>
        


    </div>

    <div id="content">
        <div id="title">
            <h1>Настройки справочников</h1>
        </div>
        <div id="navtop">
            <ul class="navul">
                <li class="btn">Статусы</li>
                <li class="btn">Типы</li>
                <li class="btn">ОПФ</li>
                <li class="btn">Должности</li>
                <li class="btn">Отделы</li>
                <li class="btn">Работы</li>
            </ul>
        </div>

        <form action="" method="POST" class="myform">
            <input class="status" type="text" name="status" placeholder="Введите название статуса">
            <input class="btn pos" type="submit" name="submit" value="Добавить">
        </form>

        <div class="tabl">

            <table>
                <tr>
                    <th id="fst">№</th>
                    <th>Статус</th>
                    <th>Действие</th>

                </tr>

                <?php 
                $query = "SELECT * FROM status";
                if ($stmt = $mysqli->prepare($query)){
                    $stmt->execute();
                    $stmt->bind_result($id,$name);
                    $i=0;
                    while ($stmt->fetch()){
                        $i++;
                        echo "<tr>";
                        echo "<td id='fst'>{$i}</td>";
                        echo "<td>{$name}</td>";
                        echo "<td id='edit'><a href='form.php?edit&id={$id}'>изменить</a></td>";
                        echo "</tr>";
                    }
                }
                ?>


            </table>
        </div>
    </div>
</div>